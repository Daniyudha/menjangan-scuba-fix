-- AlterTable
ALTER TABLE `Submission` ADD COLUMN `isRead` BOOLEAN NOT NULL DEFAULT false;
