-- AlterTable
ALTER TABLE `Testimonial` ADD COLUMN `avatarUrl` VARCHAR(191) NULL,
    ADD COLUMN `origin` VARCHAR(191) NULL;
